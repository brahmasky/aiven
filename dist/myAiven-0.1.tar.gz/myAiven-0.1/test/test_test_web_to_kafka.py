
import unittest

class web_to_kafkaTestTest(unittest.TestCase):
	"""
	Tests for methods in the web_to_kafkaTest class.
	"""

	@classmethod
	def setUpClass(cls):
		pass #TODO

	@classmethod
	def tearDownClass(cls):
		pass #TODO

	def setUp(self):
		pass #TODO

	def tearDown(self):
		pass #TODO

	def test_setUpClass(self):
		raise NotImplementedError() #TODO: test setUpClass

	def test_tearDownClass(self):
		raise NotImplementedError() #TODO: test tearDownClass

	def test_setUp(self):
		raise NotImplementedError() #TODO: test setUp

	def test_tearDown(self):
		raise NotImplementedError() #TODO: test tearDown

	def test_test_http_check(self):
		raise NotImplementedError() #TODO: test test_http_check

	def test_test_main(self):
		raise NotImplementedError() #TODO: test test_main
