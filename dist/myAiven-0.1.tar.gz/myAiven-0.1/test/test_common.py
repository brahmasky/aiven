
import unittest

class commonTest(unittest.TestCase):
	"""
	Tests for functions in the common module.
	"""

	@classmethod
	def setUpClass(cls):
		pass #TODO

	@classmethod
	def tearDownClass(cls):
		pass #TODO

	def setUp(self):
		pass #TODO

	def tearDown(self):
		pass #TODO

	def test_check_file_exist(self):
		raise NotImplementedError() #TODO: test check_file_exist

	def test_check_special_char(self):
		raise NotImplementedError() #TODO: test check_special_char

	def test_create_bcrypt_hash(self):
		raise NotImplementedError() #TODO: test create_bcrypt_hash

	def test_verify_password(self):
		raise NotImplementedError() #TODO: test verify_password

	def test_read_settings(self):
		raise NotImplementedError() #TODO: test read_settings
