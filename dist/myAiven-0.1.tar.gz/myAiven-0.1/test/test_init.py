
import unittest

class initTest(unittest.TestCase):
	"""
	Tests for functions in the init module.
	"""

	@classmethod
	def setUpClass(cls):
		pass #TODO

	@classmethod
	def tearDownClass(cls):
		pass #TODO

	def setUp(self):
		pass #TODO

	def tearDown(self):
		pass #TODO

	def test_user_input(self):
		raise NotImplementedError() #TODO: test user_input

	def test_main(self):
		raise NotImplementedError() #TODO: test main
