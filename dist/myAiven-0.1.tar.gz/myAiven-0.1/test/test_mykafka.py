
import unittest

class MyKafkaProducerTest(unittest.TestCase):
	"""
	Tests for methods in the MyKafkaProducer class.
	"""

	@classmethod
	def setUpClass(cls):
		pass #TODO

	@classmethod
	def tearDownClass(cls):
		pass #TODO

	def setUp(self):
		pass #TODO

	def tearDown(self):
		pass #TODO

	def test_send(self):
		raise NotImplementedError() #TODO: test send

class MyKafkaConsumerTest(unittest.TestCase):
	"""
	Tests for methods in the MyKafkaConsumer class.
	"""

	@classmethod
	def setUpClass(cls):
		pass #TODO

	@classmethod
	def tearDownClass(cls):
		pass #TODO

	def setUp(self):
		pass #TODO

	def tearDown(self):
		pass #TODO

	def test_receive(self):
		raise NotImplementedError() #TODO: test receive
