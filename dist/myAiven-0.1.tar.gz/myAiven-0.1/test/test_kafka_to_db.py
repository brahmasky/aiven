
import unittest

class kafka_to_dbTest(unittest.TestCase):
	"""
	Tests for functions in the kafka_to_db module.
	"""

	@classmethod
	def setUpClass(cls):
		pass #TODO

	@classmethod
	def tearDownClass(cls):
		pass #TODO

	def setUp(self):
		pass #TODO

	def tearDown(self):
		pass #TODO

	def test_main(self):
		raise NotImplementedError() #TODO: test main
