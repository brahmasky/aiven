
import unittest

class commonTestTest(unittest.TestCase):
	"""
	Tests for methods in the commonTest class.
	"""

	@classmethod
	def setUpClass(cls):
		pass #TODO

	@classmethod
	def tearDownClass(cls):
		pass #TODO

	def setUp(self):
		pass #TODO

	def tearDown(self):
		pass #TODO

	def test_setUpClass(self):
		raise NotImplementedError() #TODO: test setUpClass

	def test_tearDownClass(self):
		raise NotImplementedError() #TODO: test tearDownClass

	def test_setUp(self):
		raise NotImplementedError() #TODO: test setUp

	def test_tearDown(self):
		raise NotImplementedError() #TODO: test tearDown

	def test_test_check_file_exist(self):
		raise NotImplementedError() #TODO: test test_check_file_exist

	def test_test_check_special_char(self):
		raise NotImplementedError() #TODO: test test_check_special_char

	def test_test_create_bcrypt_hash(self):
		raise NotImplementedError() #TODO: test test_create_bcrypt_hash

	def test_test_verify_password(self):
		raise NotImplementedError() #TODO: test test_verify_password

	def test_test_read_settings(self):
		raise NotImplementedError() #TODO: test test_read_settings
