
import unittest

class MyPostgreDBTest(unittest.TestCase):
	"""
	Tests for methods in the MyPostgreDB class.
	"""

	@classmethod
	def setUpClass(cls):
		pass #TODO

	@classmethod
	def tearDownClass(cls):
		pass #TODO

	def setUp(self):
		pass #TODO

	def tearDown(self):
		pass #TODO

	def test_create_table(self):
		raise NotImplementedError() #TODO: test create_table

	def test_verify(self):
		raise NotImplementedError() #TODO: test verify

	def test_write(self):
		raise NotImplementedError() #TODO: test write

	def test_close(self):
		raise NotImplementedError() #TODO: test close
