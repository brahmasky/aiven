
import unittest

class web_to_kafkaTest(unittest.TestCase):
	"""
	Tests for functions in the web_to_kafka module.
	"""

	@classmethod
	def setUpClass(cls):
		pass #TODO

	@classmethod
	def tearDownClass(cls):
		pass #TODO

	def setUp(self):
		pass #TODO

	def tearDown(self):
		pass #TODO

	def test_http_check(self):
		raise NotImplementedError() #TODO: test http_check

	def test_main(self):
		raise NotImplementedError() #TODO: test main
