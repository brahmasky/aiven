
import unittest

class init_setupTest(unittest.TestCase):
	"""
	Tests for functions in the init_setup module.
	"""

	@classmethod
	def setUpClass(cls):
		pass #TODO

	@classmethod
	def tearDownClass(cls):
		pass #TODO

	def setUp(self):
		pass #TODO

	def tearDown(self):
		pass #TODO

	def test_user_input(self):
		raise NotImplementedError() #TODO: test user_input

	def test_main(self):
		raise NotImplementedError() #TODO: test main
