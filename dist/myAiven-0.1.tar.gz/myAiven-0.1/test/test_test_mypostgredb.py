
import unittest

class MyPostgreDBTestTest(unittest.TestCase):
	"""
	Tests for methods in the MyPostgreDBTest class.
	"""

	@classmethod
	def setUpClass(cls):
		pass #TODO

	@classmethod
	def tearDownClass(cls):
		pass #TODO

	def setUp(self):
		pass #TODO

	def tearDown(self):
		pass #TODO

	def test_setUpClass(self):
		raise NotImplementedError() #TODO: test setUpClass

	def test_tearDownClass(self):
		raise NotImplementedError() #TODO: test tearDownClass

	def test_setUp(self):
		raise NotImplementedError() #TODO: test setUp

	def test_tearDown(self):
		raise NotImplementedError() #TODO: test tearDown

	def test_test_create_table(self):
		raise NotImplementedError() #TODO: test test_create_table

	def test_test_verify(self):
		raise NotImplementedError() #TODO: test test_verify

	def test_test_write(self):
		raise NotImplementedError() #TODO: test test_write

	def test_test_close(self):
		raise NotImplementedError() #TODO: test test_close
